package com.mziuri.Product;

public class processPurchase {
    public int productId;
    public int quantity;

    public processPurchase(int productId, int quantity) {
        this.productId = productId;
        this.quantity = quantity;
    }
}
